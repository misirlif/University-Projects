/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package w1711513_cw1_leaguesimulation;

import java.io.FileNotFoundException;

/**
 *
 * @author filiz
 */
interface LeagueManager {
   public void addFootballClub();
   public void deleteFootballClub();
   public void statsDisplayFootballClub();
   public void displayPremLeagueTable();
   public void addMatch();
   public void saveFbStats();
   public void loadFbStats()throws FileNotFoundException;
}
