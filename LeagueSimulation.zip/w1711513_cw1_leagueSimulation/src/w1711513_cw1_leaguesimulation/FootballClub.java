/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package w1711513_cw1_leaguesimulation;

/**
 *
 * @author filiz
 */
public class FootballClub extends SportsClub{
    
   int goalsScored; // total goals they scored this season 
   int goalsRecieved; // total goals they received this season 
   int goalDifference; // scored-received 
   int points;
    
    FootballClub(){
        scNameOfClub = "";
        scLocationOfClub = ""; 
        
        scWins = 0;
        scDraws = 0;
        scDefeats = 0;
        scTotalMatches = 0;

        goalsScored = 0;
        goalsRecieved = 0;
        goalDifference = 0;
        
        points = 0 ;
        
    }
    
    public void setName(String scNameOfClub){
        this.scNameOfClub = scNameOfClub;
    }
    public String getName(){
        return scNameOfClub; 
    }
    
    public void setLocation(String scLocationOfClub){
        this.scLocationOfClub = scLocationOfClub;
    }
    public String getLocation(){
        return scLocationOfClub; 
    }

    public void setWins(int scWins ){
        this. scWins = scWins;
    }
    public int getWins(){
        return scWins; 
    }
    
    public void setDraws(int scDraws){
        this.scDraws = scDraws;
    }
    public int getDraws(){
        return scDraws; 
    }
    
    public void setDefeats(int scDefeats){
        this.scDefeats = scDefeats;
    }
    public int getDefeats(){
        return scDefeats; 
    }
    
    public void setTotalMatches(int scTotalMatches){
        this.scTotalMatches = scTotalMatches;
    }
    public int getTotalMatches(){
        return scTotalMatches; 
    }
    
    public void setGoalsScored(int goalsScored){
        this.goalsScored= goalsScored;
    }
    public int getGoalsScored(){
        return goalsScored; 
    }
    
    public void setGoalsRecieved(int goalsRecieved ){
        this.goalsRecieved = goalsRecieved ;
    }
    public int getGoalsRecieved(){
        return goalsRecieved ; 
    }
   
    public void setGoalsDifference(int goalsScored, int goalsRecieved){
        this.goalsScored = goalsScored; 
        this.goalsRecieved = goalsRecieved ;
        this.goalDifference = goalsScored-goalsRecieved;

    }
    public int getGoalDifference(){
        return goalDifference ; 
    }
    
     public void setPoints(int points ){
        this.points = points ;
    }
    public int getPoints(){
        return points ; 
    }
}
