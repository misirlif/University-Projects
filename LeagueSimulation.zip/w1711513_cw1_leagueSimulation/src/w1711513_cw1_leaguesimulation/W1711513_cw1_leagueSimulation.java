/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package w1711513_cw1_leaguesimulation;

import java.io.*;
import java.util.*;

/**
 *
 * @author filiz
 */
public class W1711513_cw1_leagueSimulation {
    
    /**
     * @param args the command line arguments
     * @throws java.io.FileNotFoundException
     */
    
    private static final boolean MENU_OPTIONS = true;
    public static void main(String[] args) throws FileNotFoundException { // because im calling the load and save methods 
        
        PremierLeagueManager plm = new PremierLeagueManager();
        plm.loadFbStats();
        plm.createAndShowGUI(); // show the GUI 
        
        Scanner input = new Scanner(System.in);
        
        // Decorations 
        String sep = "=========================";
        String sep1 = "*********************************************************";
        String sep2 = "- - - - - - - - - - - - - - - - - - - - - - - - - - - - -";
       
// loops the menu options, calls the cases (control structure), when the method is done it ask if they want to go back to menu or exit.
        while (MENU_OPTIONS){
            System.out.println(sep1 + "\nWelcome to the League Simulation !\n" + sep1);
            System.out.println("Please select an option:\n" + sep);
            System.out.println("A: Add new Football Club\n" + sep2);
            System.out.println("D: Delete an existing football club\n" + sep2);
            System.out.println("F: See stats for a football club\n" + sep2);
            System.out.println("P: See the Premier League Table\n" + sep2);
            System.out.println("M: Add a match played between two clubs in the premier league\n" + sep2);
            System.out.println("S: Save all data for the premier league\n" + sep2);
            System.out.println("L: Load the data for the premier league\n" + sep2);
            System.out.println("X: Exit the program\n" + sep2);
                
                String menuOption;
                System.out.println("Please enter one of the menu option:");
                menuOption = input.next();     
                menuOption = menuOption.toUpperCase();//make the options uppercase, easier for validation 
            
            switch(menuOption){
                case "A":
                    System.out.println(sep1 + "\nYou selected A: Add new Football Club\n" + sep1);
                    plm.addFootballClub();
                    plm.saveFbStats();
                    plm.loadFbStats();
                    break;
                    
                case "D":
                    System.out.println(sep1 + "\nYou selected D: Delete an existing football club\n" + sep1);
                    plm.deleteFootballClub();
                    plm.saveFbStats();
                    plm.loadFbStats();
                    break;
                    
                case "F":
                    System.out.println(sep1 + "\nYou selected F: See stats for a football club\n" + sep1);
                    plm.statsDisplayFootballClub();
                    break;
                    
                case "P":
                   System.out.println(sep1 + "\nYou selected P: See the Premier League Table\n" + sep1);
                   plm.displayPremLeagueTable();
                   break;
                    
                case "M":
                   System.out.println(sep1 + "\nYou selected M: Add a match played between two clubs in the premier league\n" + sep1);
                   plm.addMatch();
                   break;
                               
                case "S":
                   System.out.println(sep1 + "\nYou selected S: Save all data for the premier league\n" + sep1);
                   plm.saveFbStats();
                   
                   break;
                    
                case "L":
                   System.out.println(sep1 + "\nYou selected L: Load the data for the premier league\n" + sep1);
                   plm.loadFbStats();
                   break;
                    
                case "X":
                   System.out.println(sep1 + "\nYou selected X: Exit the program\n" + sep1);
                   System.out.println("\nData has been saved !\n");
                   plm.saveFbStats();// automatically save the data before exiting
                   System.exit(0);
                   break;
                    
                default: 
                    System.out.println(sep1 + "Invalid Selection, please select correct option" + sep1);
                    break;
            }
        }
        
    }
    
}
    
    

