/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package w1711513_cw1_leaguesimulation;

import java.awt.Color;
import java.io.*;
import java.util.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;

/**
 *
 * @author filiz
 */

public class PremierLeagueManager implements LeagueManager {
    List<FootballClub> fbClubs = new ArrayList<>();
    
    String sep = "=========================";
    String sep1 = "******************************";
    String sep2 = "- - - - - - - - - - - - - - -";
    
    /////////////////////// COMPARATORS ///////////////////////////////////
    
    //Comparator to sort the prem table in a descending order by points (or by GD).
    
    public static Comparator<FootballClub> points_PremTable_Descend = new Comparator<FootballClub>(){	
        @Override
        public int compare(FootballClub obj1, FootballClub obj2) {
            
                //if points are equal then sort by GD 
                if(obj2.points==obj1.points){
                    return obj2.goalDifference - obj1.goalDifference;
                }
                else{
                //sort in descending order of points
                return obj2.points-obj1.points;
                }
        }
    };  
    
    
    
    /////////////// FUNCTIONS FOR PREM MANAGER/////////////////////////
    
    @Override
    public void addFootballClub(){
        FootballClub newFB = new FootballClub();
        Scanner input = new Scanner(System.in); 
        
        // Check to see if there are any currently existing clubs in the array 
        String nameOfClub="";
        boolean clubExists = false;
         
        System.out.println("\nEnter new football club name:\n" + sep);
        //ensure that it only saves the first word that was inputted
        String name = input.nextLine();
        name = name.toUpperCase();
        String inName = name.split(" ")[0];
        
        //the first word is what gets saved as the name of club
        nameOfClub = inName;
        
        for(FootballClub fbClub : fbClubs){
            if (fbClub.scNameOfClub.equals(nameOfClub)){
               clubExists=true;
            }
        }
        if(clubExists==true){
            System.out.println("This club Exists in the league, enter a new name");
        }
        else{
            System.out.println(sep);
            //Save the name
            newFB.scNameOfClub = nameOfClub;
            
            // get the location and save the details for the new club
            String locationOfClub="";
            System.out.println("\nEnter new football club location:\n" + sep);
            
            //ensure that it only saves the first word that was inputted
            String location = input.nextLine();
            
            location=location.toUpperCase();
            
            String inLocation = location.split(" ")[0];
            
            locationOfClub= inLocation;
            
            newFB.scLocationOfClub = locationOfClub;

            fbClubs.add(newFB);
        }
    }
    
    @Override
    public void deleteFootballClub(){
        Scanner input = new Scanner(System.in);
        
       // Check to see if there are any currently existing clubs in the array 
        String nameOfClub="";
        boolean clubExists = false;
         
        System.out.println("\nEnter name to delete football club:\n" + sep);
        
        //ensure that it only saves the first word that was inputted
        String name = input.nextLine();
        name = name.toUpperCase();
        String inName = name.split(" ")[0];
        
        //the first word is what gets saved as the name of club
        nameOfClub = inName;
        
        for(FootballClub fbClub : fbClubs){
            if (fbClub.scNameOfClub.equals(nameOfClub)){
               clubExists=true;
            }
        }
        
        if(clubExists==true){
            for (int i = 0; i < fbClubs.size(); i++) {
                if (fbClubs.get(i).scNameOfClub.equals(nameOfClub)) {
                    
                    System.out.println("You have deleted the club: "+ fbClubs.get(i).scNameOfClub);
                    fbClubs.remove(i);	
                }
            }
        saveFbStats(); 
        //If a footballclub is removed i wanted to make sure that it updates it in the file
        }
        else{
            System.out.println(sep+"\nThis team doesnt exist\n"+sep);  
        }
    }
    
    
    @Override
    public void statsDisplayFootballClub(){
        Scanner input = new Scanner(System.in);
        
        String nameOfClub="";
        boolean clubExists = false;
         
        System.out.println("\nSearch for a football club:\n" + sep);
        
        String name = input.nextLine();
        name = name.toUpperCase();
        String inName = name.split(" ")[0];
        
         //the first word is what gets saved as the name of club
        nameOfClub = inName;
        
        // Validation check to see if club exists
        for(FootballClub fbClub : fbClubs){
            if (fbClub.scNameOfClub.equals(nameOfClub)){
               clubExists=true;
               System.out.println("This club Exists in the league");
            }
        }
        
        if(clubExists==true){
            for(FootballClub fbClub : fbClubs) {
                if (fbClub.scNameOfClub.equals(nameOfClub)) {
                    System.out.println(sep1+"STATS:"+sep1);
                    System.out.println("Name of club: " + fbClub.scNameOfClub);
                    System.out.println("Location of club: " + fbClub.scLocationOfClub);
                    System.out.println("Wins: " + fbClub.scWins);
                    System.out.println("Draws: " + fbClub.scDraws);
                    System.out.println("Defeats: " + fbClub.scDefeats);
                    System.out.println("Total Matches: " + fbClub.scTotalMatches);
                    System.out.println("Goals Scored: " + fbClub.goalsScored);
                    System.out.println("Goals Recieved: " + fbClub.goalsRecieved);
                    System.out.println("Goal Difference: " + fbClub.goalDifference);
                    System.out.println("Points: " + fbClub.points);
                }
            }
        }
        else{
            System.out.println(sep+"\nThis team doesnt exist\n"+sep);  
        }
    }
   
    @Override
    public void displayPremLeagueTable(){
        //call the method w/ comparator
        fbClubs.sort(points_PremTable_Descend);
        
        System.out.println("Stats of ALL the club: \n ----------------------------");
        for(FootballClub fbClub : fbClubs) {
            System.out.println("Name of club: " + fbClub.scNameOfClub);
            System.out.println("Location of club: " + fbClub.scLocationOfClub);
            System.out.println("Wins: " + fbClub.scWins);
            System.out.println("Draws: " + fbClub.scDraws);
            System.out.println("Defeats: " + fbClub.scDefeats);
            System.out.println("Total Matches: " + fbClub.scTotalMatches);
            System.out.println("Goals Scored: " + fbClub.goalsScored);
            System.out.println("Goals Recieved: " + fbClub.goalsRecieved);
            System.out.println("Goal Difference: " + fbClub.goalDifference);
            System.out.println("Points: " + fbClub.points);
            System.out.println("-----------------");
        }
    } 
    
    @Override
    public void addMatch(){
        //get the club by name
        String homeName =""; 
        String guestName ="";
        
        FootballClub homeTeam = null ;
        FootballClub guestTeam = null ;
        
        boolean homeExist = false;
        boolean guestExist = false;
        
        Scanner input = new Scanner(System.in); 
        
        System.out.println(sep+"\nHOME TEAM:\n"+sep);
        homeName= input.nextLine();
        
        System.out.println(sep+"\nGUEST TEAM:\n"+sep);
        guestName= input.nextLine();
        
         // Validation check to see if club exists
        for(FootballClub fbClub : fbClubs){
            if (fbClub.scNameOfClub.equals(homeName)){
                homeTeam = fbClub;
                homeExist=true;
            }
        }
        // Validation check to see if club exists
        for(FootballClub fbClub : fbClubs){
            if (fbClub.scNameOfClub.equals(guestName)){
                guestTeam = fbClub;
                guestExist = true;
            }
        }
        
        if(homeExist== true && guestExist == true){
            
            System.out.println(sep1+"\nBOTH TEAMS ARE IN THE LEAGUE!!! ENTER MATCH RESULTS\n"+sep1);
            
            homeTeam.scTotalMatches++;
            guestTeam.scTotalMatches++;
            
            int homeGS=0;
            int homeGR=0;
            
            System.out.println("Enter results for "+homeTeam.scNameOfClub);
            System.out.println("----------------------------");
            
            System.out.println("Home Team Goals Scored:");
            homeGS = input.nextInt();
            
            System.out.println("Home Team Goals Recieved:");
            homeGR = input.nextInt();
      
            // home team win is equal to a guest team lose and vice versa
            homeTeam.setGoalsScored(homeGS);
            homeTeam.setGoalsRecieved(homeGR);
            homeTeam.setGoalsDifference(homeGS, homeGR);
            
            guestTeam.setGoalsScored(homeGR);
            guestTeam.setGoalsRecieved(homeGS);
            guestTeam.setGoalsDifference(homeGR, homeGS);
            
            System.out.println(sep2);
            System.out.println("home GS:" + homeTeam.goalsScored);
            System.out.println("home GR:" + homeTeam.goalsRecieved);
            System.out.println("home GD:" + homeTeam.goalDifference);
            System.out.println("home TM:" + homeTeam.scTotalMatches);
            System.out.println(sep);
            System.out.println("Guest GS:" + guestTeam.goalsScored);
            System.out.println("Guest GR:" + guestTeam.goalsRecieved);
            System.out.println("Guest GD:" + guestTeam.goalDifference);
            System.out.println("Guest TM:" + guestTeam.scTotalMatches);
            System.out.println(sep2);
            
            // Points system winner = 2, draw = 1, loser = 0 ( no negative points because it may cause issues)
            if(homeTeam.goalsScored > guestTeam.goalsScored){
                System.out.println("Home Team Wins !");
                
                homeTeam.scWins++;
                homeTeam.points += 2;
                
                guestTeam.scDefeats++;
            }
            
            if(homeTeam.goalsScored < guestTeam.goalsScored){
                System.out.println("Guest Team Wins !");
                
                homeTeam.scDefeats++;
                
                guestTeam.scWins++;
                guestTeam.points += 2;
            }
            
            if(homeTeam.goalsScored == guestTeam.goalsScored){
                System.out.println("Its a Tie !");
                
                homeTeam.scDraws++;
                homeTeam.points += 1;
                
                guestTeam.scDraws++;
                guestTeam.points += 1;
            }
        }
        else{
            System.out.println("Please try again ");
        }
    }

    @Override
    public void saveFbStats(){ // put save option in menu and ask user to save before exitting program 
 
        String outputFileName = "store_input.dat";
        try
        {   // a writer object 
            PrintWriter outToFile = new PrintWriter(outputFileName);
            for(FootballClub fbClub : fbClubs){
                
                String storeName= fbClub.scNameOfClub;
                outToFile.print(storeName);
                outToFile.print(" "); // use spaces " " as a regex for loading method
          
                String storeLocation= fbClub.scLocationOfClub;
                outToFile.print(storeLocation);
                 outToFile.print(" ");
                
                int storeWins= fbClub.scWins;
                outToFile.print(storeWins);
                outToFile.print(" ");
                
                int storeDraws= fbClub.scDraws;
                outToFile.print(storeDraws);
                outToFile.print(" ");
                
                int storeDefeats= fbClub.scDefeats;
                outToFile.print(storeDefeats);
                outToFile.print(" ");
                
                int storeTotalMatches= fbClub.scTotalMatches;
                outToFile.print(storeTotalMatches);
                outToFile.print(" ");
           
                int storeGS= fbClub.goalsScored;
                outToFile.print(storeGS);
                outToFile.print(" ");
          
                int storeGR= fbClub.goalsRecieved;
                outToFile.print(storeGR);
                outToFile.print(" ");
                
                int storeGD= fbClub.goalDifference;
                outToFile.print(storeGD);
                outToFile.print(" ");
                
                int storePoints= fbClub.points;
                outToFile.print(storePoints);
                outToFile.print(" ");
                
                outToFile.println();  
            }
            outToFile.close(); 
        }
        catch(IOException e){
            System.out.println(e);
        }
    }
    
    @Override
    public void loadFbStats() throws FileNotFoundException{ 
        // automatically clears the array to avoid copies in the program
        fbClubs.clear(); 
        
        try{
            String inputFileName = "store_input.dat";
            File inputFile = new File(inputFileName);
            Scanner inFromFile = new Scanner(inputFile);

            String fbData;
            
            String loadName;
            String loadLocation;
            int loadWins;
            int loadDraws;
            int loadDefeats;
            int loadTotalMatches;
            int loadGS;
            int loadGR;
            int loadGD;
            int loadPoints;


            while (inFromFile.hasNextLine()){ //gets the next line 
                fbData = inFromFile.nextLine();
                String regex = " "; // use the space " " from file as the regex
                String[]output = fbData.split(regex);
                
                // store the data into an array and assign it to the corresponding variables
                loadName = output[0];
                loadLocation = output[1];
                loadWins = Integer.parseInt(output[2]);
                loadDraws = Integer.parseInt(output[3]);
                loadDefeats = Integer.parseInt(output[4]);
                loadTotalMatches = Integer.parseInt(output[5]);
                loadGS = Integer.parseInt(output[6]);
                loadGR = Integer.parseInt(output[7]);
                loadGD = Integer.parseInt(output[8]);
                loadPoints = Integer.parseInt(output[9]);
                
                FootballClub loadFB = new FootballClub(); //
                
            // use the corresponding set methods to the variables to store the data into a new FootballClub object
                loadFB.setName(loadName);
                loadFB.setLocation(loadLocation);
                loadFB.setWins(loadWins);
                loadFB.setDraws(loadDraws);
                loadFB.setDefeats(loadDefeats);
                loadFB.setTotalMatches(loadTotalMatches);
                loadFB.setGoalsScored(loadGS);
                loadFB.setGoalsRecieved(loadGR);
                loadFB.setGoalsDifference(loadGS, loadGR);
                loadFB.setPoints(loadPoints);
                
                fbClubs.add(loadFB);// adds a "new" football club into the array list
            }
            inFromFile.close();
        }
        catch(IOException e){
            System.out.println(e);
        }
    }
    
    /*--------------------------- PART 3 - METHODS FOR THE GUI ---------------------------------------------------*/

    /**
     *
     */
    class MyWindowListener extends WindowAdapter {
        public void windowClosing ( WindowEvent e) {
            System.out.println ("Data saved.\nClosing window !" );
            saveFbStats();//save data when closed the window
            System.exit(0);
        }
    }
    public void createAndShowGUI (){
        // Create the frame window
        JFrame frame = new JFrame ("Premier League Table" );
        JLabel txt=new JLabel("Click on headers to sort the table");  
        txt.setBounds(570,10,500,25); 
        txt.setForeground(Color.white);
        frame.add(txt);  
        JScrollPane panel = makeTable();
        frame.add(panel);
        
    ////////////////////Button for RANDOM MATCH////////////////////////////////
        
        JButton btnRandMatch=new JButton("Generate a Random Match"); 
      
        btnRandMatch.addActionListener(new ActionListener(){  
            @Override
            public void actionPerformed(ActionEvent e){  
               randomMatch();
               frame.remove(panel);
               JScrollPane panelNew = makeTable();
               frame.add(panelNew);
            }
        });
        
        btnRandMatch.setBounds(1400,10,200,50);
        btnRandMatch.setBackground(Color.orange);
        
        ////// Display the window //////
        
        frame.add(btnRandMatch);
        frame.setSize(1700, 400);
        frame.getContentPane().setBackground(Color.red);
        frame.addWindowListener( new MyWindowListener());

        frame.setLayout(null); 
        frame.setVisible( true );
        
    }

// Add a random generated match //
    public void randomMatch(){
        Random rand= new Random();
        //Randomly select 2 players 
        int indexHome;
        int indexGuest;
        
        indexHome = rand.nextInt(fbClubs.size());
        indexGuest = rand.nextInt(fbClubs.size());
        
        FootballClub homeTeam = null ;
        FootballClub guestTeam = null ;
        
        homeTeam = fbClubs.get(indexHome);
        guestTeam = fbClubs.get(indexGuest);
        
    // to avoid a match with only 1 football club 
        while(indexHome != indexGuest){ 
            homeTeam.scTotalMatches++;
            guestTeam.scTotalMatches++;

            //Randomly select the GS and GR for home team 
         
            int homeGS = rand.nextInt(30);
            int homeGR = rand.nextInt(30);

            //Update their stats
          
            homeTeam.setGoalsScored(homeGS);
            homeTeam.setGoalsRecieved(homeGR);
            homeTeam.setGoalsDifference(homeGS, homeGR);

            guestTeam.setGoalsScored(homeGR);
            guestTeam.setGoalsRecieved(homeGS);
            guestTeam.setGoalsDifference(homeGR, homeGS);

                if(homeTeam.goalsScored > guestTeam.goalsScored){
                    System.out.println("Home Team Wins !");

                    homeTeam.scWins++;
                    homeTeam.points += 2;

                    guestTeam.scDefeats++;
                }

                if(homeTeam.goalsScored < guestTeam.goalsScored){
                    System.out.println("Guest Team Wins !");

                    homeTeam.scDefeats++;

                    guestTeam.scWins++;
                    guestTeam.points += 2;
                }

                if(homeTeam.goalsScored == guestTeam.goalsScored){
                    System.out.println("Its a Tie !");

                    homeTeam.scDraws++;
                    homeTeam.points += 1;

                    guestTeam.scDraws++;
                    guestTeam.points += 1;
                }
            break;
        }
    }
    
    public JScrollPane makeTable(){
        //Set the headings
        String col[]={"Name","Location","Wins","Draws","Defeats","TM","GS","GR","GD","Points"}; 
        DefaultTableModel tableModel = new DefaultTableModel(col, 0); // The 0 argument is number rows.
        
        //populate the table with the stats from prem table
        for (FootballClub fbClub : fbClubs) {
            String name = fbClub.getName();
            String location = fbClub.getLocation();
            int wins = fbClub.getWins();
            int draws = fbClub.getDraws();
            int defeats = fbClub.getDefeats();
            int totalMatches = fbClub.getTotalMatches();
            int gs = fbClub.getGoalsScored();
            int gr = fbClub.getGoalsRecieved();
            int gd = fbClub.getGoalDifference();
            int points = fbClub.getPoints();
            Object[] data = {name,location,wins,draws,defeats,totalMatches,gs,gr,gd,points};
            tableModel.addRow(data);
        }
        
        //construct the table 
        JTable jt = new JTable(tableModel);
        jt.setRowSorter(new TableRowSorter(tableModel)); //create a table sorter 
        jt.setForeground(Color.red);
        jt.setGridColor(Color.green);
        jt.getTableHeader().setBackground(Color.orange);
        // place the table into a scroll pane 
        JScrollPane panel=new JScrollPane(jt);  
        panel.setBounds(10,50,1300,200);    
        panel.setBackground(Color.yellow);  
        return panel;
    
    }
}
     

    


