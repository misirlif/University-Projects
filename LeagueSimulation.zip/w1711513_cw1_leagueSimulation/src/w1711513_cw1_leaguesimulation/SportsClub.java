/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package w1711513_cw1_leaguesimulation;

/**
 *
 * @author filiz
 */
public abstract class SportsClub {
   String scNameOfClub;
   String scLocationOfClub; 
   
   int scWins; //matches or games they won
   int scDraws; // matches or games they drew 
   int scDefeats; //matches or games they lost 
   int scTotalMatches; //total matches or they games they played this season 
   
}