

$(function() {
	$( "#tabs" ).tabs();
});

$(function() {
	$( "button" ).button();
	$(".delete").button({disabled:true});
});

////////////////////////////////////////////////// SEARCH PAGE FILTER JQUERY UI  //////////////////////////////////

$(function() {
	$("#type").selectmenu();
});


$(function() {
	$("#slider-range").slider({
		range:true,
		min: 399995,
		max: 900000,
		slide: function( event, ui ){
			$("#amount").val( "£" + ui.values[ 0 ] + " - £" + ui.values[ 1 ] );
		}
	});
	
	$("#amount").val(" £" + $(" #slider-range").slider( "values", 0 ) + " - £" + $("#slider-range").slider( "values", 1 ) );
});

$(function() {
	$("#spinnerMin").spinner({
		min: 1,
		max: 5,
		spin: function(event, ui) {
			$(this).change();
		}
	});
});

$(function() {
	$("#spinnerMax").spinner({
		min: 1,
		max: 5,
		spin: function(event, ui) {
			$(this).change();
		}
	});
});

$(function(){
	$( "#dateFrom" ).datepicker({
	  defaultDate: "-12m",
	  changeMonth: true,
	  minDate: "01/01/2020",
	  maxDate: "12/31/2020",
	  numberOfMonths: 1,
	  onClose: function( selectedDate ) {
		$( "#to" ).datepicker( "option", "minDate", selectedDate );
	  }
	});
});

$(function() {
	$( "#dateTo" ).datepicker({
	  defaultDate: "0m",
	  changeMonth: true,
	  minDate: "01/01/2020",
	  maxDate: "12/31/2020",
	  numberOfMonths: 1,
	  onClose: function( selectedDate ) {
		$( "#from" ).datepicker( "option", "maxDate", selectedDate );
	  }
	});	
});

////////////////////////////////////////////////// SEARCH PAGE FILTER FUNCTIONS //////////////////////////////////

$(function() {
	$( "#searchProp").on("click", function(){
		
		//getting type
		var type = $("#type").val();
		
		//getting date MONTH , DAY and YEAR
		var dateFrom = $("#dateFrom").val();
		var dateTo= $("#dateTo").val();
		
		// using regex to get each number from the date picker
		var regex ="/";
		
		var from = dateFrom.split(regex);
		var to = dateTo.split(regex);
		
		var fromMonth=from[0];
		var fromDay=from[1];
		var fromYear =from[2];
		
		var toMonth=to[0];
		var toDay=to[1];
		var toYear=to[2];
		
		// getting min and max bed and price 
		var minBed= $("#spinnerMin").val();
		var maxBed= $("#spinnerMax").val();
		
		var minPrice= $("#slider-range").slider("option", "values")[0];
		var maxPrice=$("#slider-range").slider("option", "values")[1];
		
		//TESTING FORM VALUES : var output="<p> type: " + type + " fromday: " + fromDay + " from month: " + fromMonth +" from year: " + fromYear + " to day: " + toDay + " to month: " + toMonth + " to year: " + toYear +" min beds: "+ minBed + " max beds: " +maxBed + " min price: "+ minPrice  +" max price: "+ maxPrice +"</p>";
		
		var minB = parseInt(minBed);
		var maxB = parseInt(maxBed);
		
		if(((dateFrom == "") && (dateTo == "")) || (minB > maxB))
		{
			// if the form isnt fully or incorrectly filled out an alert will appear and reload the page to still display the default search results
			alert("You have not filled out the form correctly, please try again. This page is reloading !");
			location.reload();
			
		}
		
		//Format the json data output
		var searchRes = "<h2 id='resTitle'>Search Results:</h2>";
		var output = "";
		   for (var i in data.properties){
			   if (( type == data.properties[i].type) || (type=="All")) // - it works
			   if (( data.properties[i].bedrooms >= minBed) && (data.properties[i].bedrooms <= maxBed)) // - it works
			   if (( data.properties[i].price >= minPrice) && (data.properties[i].price <= maxPrice )) // - it works
			   if ((( data.properties[i].added.month >= fromMonth) && (data.properties[i].added.month <= toMonth))&&(( data.properties[i].added.day >= fromDay)&&(data.properties[i].added.day 	<= toDay))&&(( data.properties[i].added.year >= fromYear) && (data.properties[i].added.year <= toYear)))
			   {
				 {
				   {
					 {
						   
							   output += "<table class='card'><tr><td><img src='"+ data.properties[i].picture+"'></td><td><h2>"+ data.properties[i].name +"</h2><ul><li>TYPE: <span>" + data.properties[i].type +"</span></li><li>PRICE: <span>£ " +data.properties[i].price+"</span></li><li>BEDROOMS: <span>" + data.properties[i].bedrooms +"</span></li><li>DATE ADDED: <span>"+ " "+ data.properties[i].added.month+ "/" + data.properties[i].added.day+ "/" + data.properties[i].added.year+"</span></li></ul><a href='"+ data.properties[i].url +"'>Visit page</a></td></tr><tr><td colspan='2'><p>"+ data.properties[i].description + "</p></td></tr></table>";
			   
			   				
					   }
				     }
			      }
			   }

			}
			// if no results dialog box and make output a no search message
			if(output==""){
				output="<h1 id='noResults'> Sorry no houses found, please try a different search ! </h1>"
				$( "#dialog" ).dialog({
					position: { 
						my: "left top", 
						at: "left top",
						of: window
					},
					modal: true,
					show: {
        				effect: "blind",
        				duration: 1000
      				}
				});
			}
	    	document.getElementById("results").innerHTML = searchRes+output;
		
	});
});

////////////////////////////////////////////////// FAV LIST , VIEW FAV , CLEAR FAV  FUNCTIONS //////////////////////////////////

// **************** favourties in all property pages ********************
//**************************************************************************************************************************************************
function addFav(){
		try {
			$(".addToFav").button({disabled:true});
			$(".delete").button({disabled:false});
			
			var propIdAdd = $(".title").attr("id");
			
			var propName = $(".propName").text();
			
			var myFavProp=JSON.parse(localStorage.getItem("favProp"));
			
			alert("Current Fav list: "+myFavProp);
			
			if(myFavProp == null) {
				myFavProp = [];
			}
			
			if(myFavProp != null) {
				for ( var j = 0; j < myFavProp.length; j++) {
					
					if ( propIdAdd == myFavProp[j]) {
						alert("This property is already in your favourites"); 
						myFavProp = [];
					}
				}
			}
			
			myFavProp.push(propIdAdd);
			
			alert("Updated fav list : "+myFavProp);
			
			localStorage.setItem("favProp", JSON.stringify(myFavProp));
			
			document.getElementById("favList").innerHTML ="<div class='faved'><img src='../_property_images/"+propIdAdd+"pic1.jpg'><span>"+propName+"</span></div>";
			$("div.faved").draggable();
		}
		
		catch (e) {
			if (e=="QUOTA_EXCEEDED_ERR") {
				console.log("Error: Local storage limit exceeds");
				alert("This property is not saved.")
				
				location.reload();
				localStorage.clear();
				$(this).button({disabled:false});
			}
			
			else {
				console.log("ERROR: Saving to local storge.");
				alert("This property is not saved.")
				
				location.reload();
				localStorage.clear();
				$(this).button({disabled:false});
				
			}
		}
}

// REMOVE FROM FAV LIST BY dragging .faved TO .main


// ADD TO FAV LIST BY CLICKIN ON .addToFav
$(".addToFav").on("click", addFav);

// ADD TO FAV LIST BY dragging .propName

$(".propName").draggable({ 
	opacity: 0.7, 
	revert:true
});

$("#favList").droppable({
	hoverClass:"hover",
	accept:".propName",
	drop: function( event, ui ) {
       addFav(ui.draggable);
    }
});


function removeFav(){
		$(".addToFav").button({disabled:false});
		$(".delete").button({disabled:true});
	
		$(".faved").remove();
	
		var propIdRemove = $(".title").attr("id");

		myFavProp=JSON.parse(localStorage.getItem("favProp"));

		if(myFavProp != null) {
			for ( var j = 0; j < myFavProp.length; j++) {

				if ( propIdRemove == myFavProp[j]) {

					alert("Removed from fav list");

					delete myFavProp[j];

					localStorage.setItem("favProp", JSON.stringify(myFavProp));

					myFavProp[j] = [];
				}
			}
		}

		$(".addToFav").button({disabled:false});
		$(".delete").button({disabled:true});
}


// REMOVE FROM FAV LIST BY CLICKING .delete
$(".delete").on("click", removeFav);

$(".main").droppable({
	hoverClass:"hover",
	accept:".faved",
	drop: function( event, ui ) {
       removeFav(ui.draggable);
    }
});


//**************************************************************************************************************************************************
// **************** view and clear favorites in index page ********************

$(function() {
	$( "#viewFavs" ).on("click", function(){
		
		console.log("Restoring array data from local storage");
		
		myFavProp=JSON.parse(localStorage.getItem("favProp"));
		
		var searchRes = "<h2 id='resTitle'>Your favourties:</h2>";
		var output = "";
		if (myFavProp != null) {
			
			for (var i = 0; i < data.properties.length; i++) {
				for (var j = 0; j < myFavProp.length; j++) {
					
					if (data.properties[i].id == myFavProp[j]) {
						
						output += "<table class='card'><tr><td><img src='"+ data.properties[i].picture+"'></td><td><h2>"+ data.properties[i].name +"</h2><ul><li>TYPE: <span>" + data.properties[i].type +"</span></li><li>PRICE: <span>£ " +data.properties[i].price+"</span></li><li>BEDROOMS: <span>" + data.properties[i].bedrooms +"</span></li><li>DATE ADDED: <span>"+ " "+ data.properties[i].added.month+ "/" + data.properties[i].added.day+ "/" + data.properties[i].added.year+"</span></li></ul><a href='"+ data.properties[i].url +"'>Visit page</a></td></tr><tr><td colspan='2'><p>"+ data.properties[i].description + "</p></td></tr></table>";
					}
				}
			}
			document.getElementById("results").innerHTML = searchRes+output;
		}
		
		if (myFavProp == null) {
			document.getElementById("results").innerHTML ="<h2 id='resTitle'>Your favourties list is empty!</h2>";
		}
	    
	
	});
});


$(function() {
	$( "#clearFavs" ).on("click", function(){
		
		document.getElementById("results").innerHTML ="<h2 id='resTitle'>Your favourites list has been cleared !</h2>";
		
		myFavProp=JSON.parse(localStorage.getItem("favProp"));
		
		localStorage.clear();
		
	});
	
});



